import pytest
from PyQt5 import QtWidgets

from itech_interface import gui
from itech_interface.gui import (
    MainWindow,
    MeasurementWorker,
    AD_START_VOLTAGE,
    AT_AL_START_VOLTAGE,
    INNESCO_START_VOLTAGE,
    TEST_CURRENT_A,
    INNESCO_DIODE_OFFSET_V,
)


class DummyConn:
    def __init__(self, host=None):
        # host argument ignored; provided for compatibility with ITechConnection
        self.sent = []
        self.connected = False
    def connect(self):
        self.connected = True
    def disconnect(self):
        self.connected = False
    def send(self, cmd):
        self.sent.append(cmd)
    def query(self, cmd):
        return "1.23"


@pytest.fixture(scope="module")
def qapp():
    # ensure a QApplication exists for widget construction
    app = QtWidgets.QApplication.instance()
    if app is None:
        app = QtWidgets.QApplication([])
    return app


def test_default_ip_and_auto_connect(monkeypatch, qapp):
    # replace the network connection class used by the GUI
    monkeypatch.setattr(gui, "ITechConnection", DummyConn)

    window = MainWindow()
    # the auto-connect is scheduled via QTimer; process events so it can run
    qapp.processEvents()

    # auto-connect should have been attempted and controller created
    assert isinstance(window.ctrl, gui.PowerSupplyController)
    # dummy connection should report connected
    assert window.conn.connected is True
    assert window.result_label.text() == "Connected"


def test_voltage_buttons(monkeypatch, qapp):
    monkeypatch.setattr(gui, "ITechConnection", DummyConn)
    window = MainWindow()
    qapp.processEvents()
    # grab dummy connection used by controller
    dummy = window.conn
    assert isinstance(dummy, DummyConn)

    # click 100V button
    window.voltage_100_btn.click()
    assert "VOLT 100" in dummy.sent

    # click 500V button
    window.voltage_500_btn.click()
    assert "VOLT 500" in dummy.sent


def test_measure_worker_timing(monkeypatch, qapp):
    # create a dummy controller with sleep to simulate delay
    class SlowCtrl:
        def measure_voltage(self):
            import time
            time.sleep(0.01)
            return 2.34

    worker = MeasurementWorker(SlowCtrl())
    results = []
    worker.result.connect(lambda v, t: results.append((v, t)))
    worker.start()
    # wait for thread to finish
    worker.wait()
    # process Qt events to ensure signal delivery
    qapp.processEvents()
    assert results, "worker did not emit results"
    v, elapsed = results[0]
    assert v == 2.34
    assert elapsed >= 0.01


def test_test_procedure_buttons(monkeypatch, qapp):
    # verify that clicking each new button updates the label appropriately
    monkeypatch.setattr(gui, "ITechConnection", DummyConn)
    window = MainWindow()
    qapp.processEvents()

    window.ad_btn.click()
    # popup should appear with instructions and buttons
    assert hasattr(window, '_ad_popup')
    popup = window._ad_popup
    # locate buttons by iterating children and matching text
    buttons = popup.findChildren(QtWidgets.QPushButton)
    start_btn = next((b for b in buttons if b.text() == "INIZIO TEST"), None)
    trip_btn = next((b for b in buttons if b.text() == "Cartellino scattato"), None)
    close_btn = next((b for b in buttons if b.text() == "Chiudi"), None)
    assert start_btn is not None
    assert trip_btn is not None
    assert close_btn is not None
    assert not trip_btn.isEnabled()
    # find status label (last QLabel added)
    labels = popup.findChildren(QtWidgets.QLabel)
    status_label = labels[-1]
    assert "Tensione applicata" in status_label.text()
    # closing popup via button should hide it
    close_btn.click()
    assert not popup.isVisible()

    # simulate clicking start and a few voltage increments
    start_btn.click()
    # after start, trip button enabled and initial commands sent
    assert trip_btn.isEnabled()
    assert f"VOLT {AD_START_VOLTAGE}" in window.conn.sent
    assert f"CURR {TEST_CURRENT_A}" in window.conn.sent
    assert "OUTP ON" in window.conn.sent
    # simulate a couple of timer ticks manually
    window._ad_step()
    window._ad_step()
    assert f"VOLT {AD_START_VOLTAGE + 1}" in window.conn.sent
    assert f"VOLT {AD_START_VOLTAGE + 2}" in window.conn.sent
    # status label updated accordingly
    assert f"Tensione applicata: {AD_START_VOLTAGE + 2}" in status_label.text()
    # simulate trip button
    trip_btn.click()
    assert "Cartellino scattato a" in status_label.text()
    # ensure timer stopped
    assert not getattr(window, '_ad_timer').isActive()
    # output should be disabled then device put in local
    assert "OUTP OFF" in window.conn.sent
    assert "SYST:LOC" in window.conn.sent

    window.ad_al_btn.click()
    # popup created with two cartellino buttons
    assert hasattr(window, '_at_al_popup')
    popup2 = window._at_al_popup
    buttons = popup2.findChildren(QtWidgets.QPushButton)
    start_btn = next((b for b in buttons if b.text() == "INIZIO TEST"), None)
    cart1_btn = next((b for b in buttons if b.text() == "Cartellino 1 scattato"), None)
    cart2_btn = next((b for b in buttons if b.text() == "Cartellino 2 scattato"), None)
    close_btn2 = next((b for b in buttons if b.text() == "Chiudi"), None)
    assert start_btn is not None and cart1_btn is not None and cart2_btn is not None and close_btn2 is not None
    assert not cart1_btn.isEnabled()
    assert not cart2_btn.isEnabled()
    # closing second popup
    close_btn2.click()
    assert not popup2.isVisible()
    # start test
    start_btn.click()
    assert cart1_btn.isEnabled()
    assert f"VOLT {AT_AL_START_VOLTAGE}" in window.conn.sent
    assert f"CURR {TEST_CURRENT_A}" in window.conn.sent
    assert "OUTP ON" in window.conn.sent
    # simulate couple of steps
    window._at_al_step()
    window._at_al_step()
    assert f"VOLT {AT_AL_START_VOLTAGE + 1}" in window.conn.sent
    assert f"VOLT {AT_AL_START_VOLTAGE + 2}" in window.conn.sent
    # press cart1 and check label
    cart1_btn.click()
    assert hasattr(window, '_at_al_cart1_value')
    assert "Cartellino1" in window._at_al_cart1_label.text()
    # second button enabled
    assert cart2_btn.isEnabled()
    # press cart2 and verify stop and local/off commands
    cart2_btn.click()
    assert "OUTP OFF" in window.conn.sent
    assert "SYST:LOC" in window.conn.sent
    assert not getattr(window, '_at_al_timer').isActive()

    window.innesco_btn.click()
    # pre-test popup should appear
    assert hasattr(window, '_pre_innesco_popup')
    pre_popup = window._pre_innesco_popup
    pre_buttons = pre_popup.findChildren(QtWidgets.QPushButton)
    pre_start = next((b for b in pre_buttons if b.text() == "INIZIO TEST"), None)
    pre_close = next((b for b in pre_buttons if b.text() == "Chiudi"), None)
    assert pre_start is not None and pre_close is not None
    # ensure close works
    pre_close.click()
    assert not pre_popup.isVisible()
    # reopen to continue normal sequence
    window.innesco_btn.click()
    pre_popup = window._pre_innesco_popup
    pre_buttons = pre_popup.findChildren(QtWidgets.QPushButton)
    pre_start = next((b for b in pre_buttons if b.text() == "INIZIO TEST"), None)
    pre_start.click()
    assert "Innesco test started" in window.result_label.text()

    # also verify the main window quit button hides the window
    window.quit_btn.click()
    assert not window.isVisible()
    # recreate window to continue testing further routines
    window = MainWindow()
    qapp.processEvents()

    # now test innesco tiristore procedure
    class CounterCtrl(DummyConn):
        def __init__(self, host=None):
            super().__init__(host)
            # will return increasing values then a drop
            self._meas_seq = [89, 90, 91, 89]
        def query(self, cmd):
            # ignore command string, pop next measurement
            if self._meas_seq:
                return str(self._meas_seq.pop(0))
            return "120"
    # patch the connection to our counter
    monkeypatch.setattr(gui, "ITechConnection", CounterCtrl)
    window = MainWindow()
    qapp.processEvents()
    window.innesco_btn.click()
    # click pre-test start button as before
    assert hasattr(window, '_pre_innesco_popup')
    pre_popup2 = window._pre_innesco_popup
    pre_buttons2 = pre_popup2.findChildren(QtWidgets.QPushButton)
    pre_start2 = next((b for b in pre_buttons2 if b.text() == "INIZIO TEST"), None)
    assert pre_start2 is not None
    pre_start2.click()
    # initial commands should be sent
    assert f"VOLT {INNESCO_START_VOLTAGE}" in window.conn.sent
    assert f"CURR {TEST_CURRENT_A}" in window.conn.sent
    assert "OUTP ON" in window.conn.sent
    # simulate timer steps until drop
    while getattr(window, '_innesco_timer').isActive():
        window._innesco_step()
    # after stopping, history should contain at least two values
    assert len(window._innesco_history) >= 2
    # history should include the drop (last < previous)
    assert window._innesco_history[-1] < window._innesco_history[-2]
    # simulate the delayed diode drop measurement
    window._calculate_diode_drop(max(window._innesco_history[:-1]))
    label_text = window._innesco_label.text()
    assert "Valore massimo raggiunto" in label_text
    assert "Caduta diodo" in label_text
    # adjusted drop should equal raw (120) minus the configured offset
    _raw_mock = 120.0
    assert f"{_raw_mock - INNESCO_DIODE_OFFSET_V:.2f}" in label_text
    # countdown text should initially show 3 seconds
    assert "Spegnimento in 3 secondi" in label_text
    # simulate timer ticks to drive the countdown to zero
    for i in (3, 2, 1):
        window._shutdown_countdown_step()
        assert f"Spegnimento in {i-1} secondi" in window._innesco_label.text()
    # after countdown has completed the output is turned off
    assert "OUTP OFF" in window.conn.sent
    # first line should show maximum, not the raw measured value (120 measured -> not in first line)
    assert "120" not in label_text.splitlines()[0]
    assert "registrare il valore" in label_text
    # now press exit button
    exit_btn = window._innesco_popup.findChild(QtWidgets.QPushButton)
    exit_btn.click()
    assert "OUTP OFF" in window.conn.sent
    assert "SYST:LOC" in window.conn.sent
