"""Networking layer to communicate with the ITECH power supply."""

import socket
import logging
from typing import Optional

LOGGER = logging.getLogger(__name__)

class ITechConnection:
    """Simple TCP client for SCPI commands to the ITECH device."""

    def __init__(self, host: str, port: int = 5025, timeout: float = 5.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self._sock: Optional[socket.socket] = None

    def connect(self) -> None:
        LOGGER.debug("Connecting to %s:%s", self.host, self.port)
        self._sock = socket.create_connection((self.host, self.port), self.timeout)
        self._sock.settimeout(self.timeout)

    def disconnect(self) -> None:
        if self._sock:
            LOGGER.debug("Disconnecting from device")
            self._sock.close()
            self._sock = None

    def send(self, command: str) -> None:
        if not self._sock:
            raise RuntimeError("Not connected")
        LOGGER.debug("Sending command: %s", command)
        self._sock.sendall(command.encode("ascii") + b"\n")

    def query(self, command: str) -> str:
        self.send(command)
        if not self._sock:
            raise RuntimeError("Not connected")
        data = self._sock.recv(4096)
        result = data.decode("ascii").strip()
        LOGGER.debug("Received: %s", result)
        return result
