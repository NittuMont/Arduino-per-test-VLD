"""GUI implementation using PyQt5."""

from PyQt5 import QtWidgets, QtCore
import time
from .controller import PowerSupplyController
from .network import ITechConnection

# ---------------------------------------------------------------------------
# Configuration constants
# ---------------------------------------------------------------------------

# Network
DEFAULT_HOST = "192.168.1.100"

# Common test parameters
TEST_MAX_VOLTAGE = 120       # V — upper bound for all three ramps
TEST_CURRENT_A = 2           # A — current limit applied before each ramp

# Anomalia Diodo (AD) test
AD_START_VOLTAGE = 87        # V — voltage at INIZIO TEST
AD_TIMER_INTERVAL_MS = 1000  # ms — ramp step interval

# Anomalia Tiristore e Limiti (AT + AL) test
AT_AL_START_VOLTAGE = 88        # V
AT_AL_TIMER_INTERVAL_MS = 1000  # ms

# Innesco Tiristore test
INNESCO_START_VOLTAGE = 89       # V
INNESCO_TIMER_INTERVAL_MS = 500  # ms — half-second steps
INNESCO_DIODE_DELAY_MS = 1000    # ms — wait after trip before reading diode drop
INNESCO_DIODE_OFFSET_V = 10.55   # V — subtracted from raw reading to get diode drop

class MeasurementWorker(QtCore.QThread):
    """Background thread to perform voltage measurement only.

    The signal includes voltage and elapsed seconds for the query operation.
    """
    result = QtCore.pyqtSignal(float, float)

    def __init__(self, controller: PowerSupplyController):
        super().__init__()
        self.ctrl = controller

    def run(self):
        # perform voltage query only
        start = time.monotonic()
        v = self.ctrl.measure_voltage()
        elapsed = time.monotonic() - start
        self.result.emit(v, elapsed)


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ITECH IT6018C Control")
        self._setup_ui()
        self.conn = None
        self.ctrl = None
        # worker instance reused for measurements (created each time)
        self._measure_worker = None

    def _setup_ui(self):
        # ----------------------------------------------------------------
        # Global stylesheet — font size 18pt, generous button height/padding
        # All child widgets inherit font size automatically.
        # ----------------------------------------------------------------
        self.setStyleSheet("""
            * {
                font-size: 18pt;
            }
            QPushButton {
                min-height: 56px;
                padding: 8px 20px;
            }
            QLabel {
                padding: 4px 0px;
            }
        """)

        central = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout()
        layout.setSpacing(12)
        layout.setContentsMargins(20, 20, 20, 20)

        # (IP textbox removed) connection will always use the default address
        # and attempt autoconnect on startup.

        # additional preset voltage buttons requested by user
        self.voltage_100_btn = QtWidgets.QPushButton("Set 100V")
        self.voltage_100_btn.clicked.connect(lambda: self.ctrl.set_voltage(100))
        layout.addWidget(self.voltage_100_btn)

        self.voltage_500_btn = QtWidgets.QPushButton("Set 500V")
        self.voltage_500_btn.clicked.connect(lambda: self.ctrl.set_voltage(500))
        layout.addWidget(self.voltage_500_btn)

        # real test procedure buttons (labels requested by user)
        self.ad_btn = QtWidgets.QPushButton("Anomalia Diodo (AD)")
        self.ad_btn.clicked.connect(self.on_test_anomalia_diodo)
        layout.addWidget(self.ad_btn)

        self.ad_al_btn = QtWidgets.QPushButton("Anomalia Tiristore e Limiti (AT e AL)")
        self.ad_al_btn.clicked.connect(self.on_test_anomalia_tiristore_limiti)
        layout.addWidget(self.ad_al_btn)

        self.innesco_btn = QtWidgets.QPushButton("Innesco Tiristore")
        self.innesco_btn.clicked.connect(self.on_test_innesco_tiristore)
        layout.addWidget(self.innesco_btn)

        # quit application button
        self.quit_btn = QtWidgets.QPushButton("Esci")
        self.quit_btn.clicked.connect(self.close)
        layout.addWidget(self.quit_btn)

        self.result_label = QtWidgets.QLabel("---")
        layout.addWidget(self.result_label)

        # attempt automatic connection once UI is shown
        QtCore.QTimer.singleShot(0, self._auto_connect)

        central.setLayout(layout)
        self.setCentralWidget(central)


    def on_measure(self):
        # retained for possible future use but no UI button triggers it
        if not self.ctrl:
            return
        # disable button to prevent multiple concurrent requests
        self.measure_btn.setEnabled(False)
        self.result_label.setText("Measuring...")
        # start background thread
        self._measure_worker = MeasurementWorker(self.ctrl)
        self._measure_worker.result.connect(self._on_measure_complete)
        self._measure_worker.start()

    def _auto_connect(self):
        # always attempt to connect to the default address
        host = DEFAULT_HOST
        self.conn = ITechConnection(host)
        try:
            self.conn.connect()
            self.ctrl = PowerSupplyController(self.conn)
            self.result_label.setText("Connected")
        except Exception as e:
            self.result_label.setText(f"Error: {e}")

    # placeholders for future test routines
    def on_test_anomalia_diodo(self):
        # show instructions before starting AD routine
        popup = QtWidgets.QDialog(self)
        popup.setWindowTitle("Anomalia Diodo (AD)")
        layout = QtWidgets.QVBoxLayout()
        instructions = QtWidgets.QLabel(
            "Collegare l'alimentatore con il positivo al punto \"B\" (binario) e il negativo al punto \"T\" (palo).\n"
            "Collegare il filo rosso al faston TP1 e il filo nero al faston TP4.\n"
            "Lasciare il filo bianco non connesso."
        )
        instructions.setWordWrap(True)
        layout.addWidget(instructions)

        start_btn = QtWidgets.QPushButton("INIZIO TEST")
        layout.addWidget(start_btn)

        trip_btn = QtWidgets.QPushButton("Cartellino scattato")
        trip_btn.setEnabled(False)
        layout.addWidget(trip_btn)

        status_label = QtWidgets.QLabel("Tensione applicata: 0 V")
        layout.addWidget(status_label)

        # allow the user to dismiss the popup without running the test
        close_btn = QtWidgets.QPushButton("Chiudi")
        layout.addWidget(close_btn)
        close_btn.clicked.connect(popup.close)

        popup.setLayout(layout)
        self._ad_popup = popup
        self._ad_status_label = status_label
        self._ad_trip_btn = trip_btn
        popup.adjustSize()
        popup.show()

        # connect buttons
        start_btn.clicked.connect(self._start_ad_test)
        trip_btn.clicked.connect(self._ad_tripped)

    def _start_ad_test(self):
        # start the AD test sequence
        if not self.ctrl:
            return
        self.ctrl.set_voltage(AD_START_VOLTAGE)
        self.ctrl.set_current(TEST_CURRENT_A)
        self.ctrl.output_on()
        self._ad_voltage = AD_START_VOLTAGE
        # enable trip button now
        self._ad_trip_btn.setEnabled(True)
        # update label
        self._ad_status_label.setText(f"Tensione applicata: {self._ad_voltage} V")
        # timer to increase voltage
        self._ad_timer = QtCore.QTimer(self)
        self._ad_timer.timeout.connect(self._ad_step)
        self._ad_timer.start(AD_TIMER_INTERVAL_MS)

    def _ad_step(self):
        if self._ad_voltage >= TEST_MAX_VOLTAGE:
            self._ad_timer.stop()
            return
        self._ad_voltage += 1
        self.ctrl.set_voltage(self._ad_voltage)
        self._ad_status_label.setText(f"Tensione applicata: {self._ad_voltage} V")

    def _ad_tripped(self):
        # user clicked trip button; show voltage and stop timer
        if hasattr(self, "_ad_timer") and self._ad_timer.isActive():
            self._ad_timer.stop()
        self._ad_status_label.setText(f"Cartellino scattato a {self._ad_voltage} V")
        # turn power off before returning to local
        if self.ctrl:
            try:
                self.ctrl.output_off()
            except Exception:
                pass
        try:
            self.ctrl.local_mode()
        except Exception:
            pass

    def on_test_anomalia_tiristore_limiti(self):
        # perform AT + AL routine with two cartellini
        if not self.ctrl:
            return
        # show popup instructions
        popup = QtWidgets.QDialog(self)
        popup.setWindowTitle("Test AT e AL")
        layout = QtWidgets.QVBoxLayout()
        label = QtWidgets.QLabel(
            "Spostare il filo rosso sul faston TP4 e il filo nero sul faston TP1.\n"
            "Lasciare il filo bianco non connesso."
        )
        label.setWordWrap(True)
        layout.addWidget(label)

        start_btn = QtWidgets.QPushButton("INIZIO TEST")
        layout.addWidget(start_btn)

        cart1_btn = QtWidgets.QPushButton("Cartellino 1 scattato")
        cart1_btn.setEnabled(False)
        layout.addWidget(cart1_btn)
        cart1_label = QtWidgets.QLabel("Cartellino1: - V")
        layout.addWidget(cart1_label)

        cart2_btn = QtWidgets.QPushButton("Cartellino 2 scattato")
        cart2_btn.setEnabled(False)
        layout.addWidget(cart2_btn)
        cart2_label = QtWidgets.QLabel("Cartellino2: - V")
        layout.addWidget(cart2_label)

        # close/cancel popup button
        close_btn2 = QtWidgets.QPushButton("Chiudi")
        layout.addWidget(close_btn2)
        close_btn2.clicked.connect(popup.close)

        popup.setLayout(layout)
        self._at_al_popup = popup
        self._at_al_cart1_btn = cart1_btn
        self._at_al_cart2_btn = cart2_btn
        self._at_al_cart1_label = cart1_label
        self._at_al_cart2_label = cart2_label
        popup.adjustSize()
        popup.show()

        start_btn.clicked.connect(self._start_at_al_test)
        cart1_btn.clicked.connect(self._at_al_cart1)
        cart2_btn.clicked.connect(self._at_al_cart2)

    def _start_at_al_test(self):
        if not self.ctrl:
            return
        self.ctrl.set_voltage(AT_AL_START_VOLTAGE)
        self.ctrl.set_current(TEST_CURRENT_A)
        self.ctrl.output_on()
        self._at_al_voltage = AT_AL_START_VOLTAGE
        # enable first cartellino button
        self._at_al_cart1_btn.setEnabled(True)
        # timer for increments
        self._at_al_timer = QtCore.QTimer(self)
        self._at_al_timer.timeout.connect(self._at_al_step)
        self._at_al_timer.start(AT_AL_TIMER_INTERVAL_MS)

    def _at_al_step(self):
        if self._at_al_voltage >= TEST_MAX_VOLTAGE:
            self._at_al_timer.stop()
            return
        # continue incrementing until both buttons pressed
        self._at_al_voltage += 1
        self.ctrl.set_voltage(self._at_al_voltage)
        # update labels if recorded
        if hasattr(self, '_at_al_cart1_value'):
            self._at_al_cart1_label.setText(f"Cartellino1: {self._at_al_cart1_value} V")
        if hasattr(self, '_at_al_cart2_value'):
            self._at_al_cart2_label.setText(f"Cartellino2: {self._at_al_cart2_value} V")

    def _at_al_cart1(self):
        # record voltage and enable second button
        self._at_al_cart1_value = self._at_al_voltage
        self._at_al_cart1_label.setText(f"Cartellino1: {self._at_al_cart1_value} V")
        self._at_al_cart2_btn.setEnabled(True)

    def _at_al_cart2(self):
        # record second voltage and end test
        self._at_al_cart2_value = self._at_al_voltage
        self._at_al_cart2_label.setText(f"Cartellino2: {self._at_al_cart2_value} V")
        if hasattr(self, '_at_al_timer') and self._at_al_timer.isActive():
            self._at_al_timer.stop()
        # turn off output and go local
        try:
            self.ctrl.output_off()
        except Exception:
            pass
        try:
            self.ctrl.local_mode()
        except Exception:
            pass
        # popup may remain for user to see values

    def _ad_al_step(self):
        # called each second by timer
        if self._ad_al_voltage >= TEST_MAX_VOLTAGE:
            self._ad_al_timer.stop()
            return
        self._ad_al_voltage += 1
        self.ctrl.set_voltage(self._ad_al_voltage)

    def _stop_ad_al_test(self):
        # triggered by popup button
        if hasattr(self, "_ad_al_timer"):
            self._ad_al_timer.stop()
        if self.ctrl:
            self.ctrl.output_off()
        if hasattr(self, "_ad_al_popup"):
            self._ad_al_popup.close()
            del self._ad_al_popup

    def on_test_innesco_tiristore(self):
        # preliminary popup instructing connection of white wire
        popup = QtWidgets.QDialog(self)
        popup.setWindowTitle("Innesco Tiristore")
        layout = QtWidgets.QVBoxLayout()
        label = QtWidgets.QLabel("Collegare il filo bianco al faston TP2.")
        label.setWordWrap(True)
        layout.addWidget(label)
        start_btn = QtWidgets.QPushButton("INIZIO TEST")
        layout.addWidget(start_btn)
        # add explicit close button here as well
        cancel_btn = QtWidgets.QPushButton("Chiudi")
        layout.addWidget(cancel_btn)
        cancel_btn.clicked.connect(popup.close)
        popup.setLayout(layout)
        self._pre_innesco_popup = popup
        start_btn.clicked.connect(lambda: (popup.close(), self._begin_innesco()))
        popup.adjustSize()
        popup.show()

    def _begin_innesco(self):
        # actual test sequence after initial instruction
        self.result_label.setText("Innesco test started")
        if not self.ctrl:
            return
        # setup initial output
        self.ctrl.set_voltage(INNESCO_START_VOLTAGE)
        self.ctrl.set_current(TEST_CURRENT_A)
        self.ctrl.output_on()
        self._innesco_voltage = INNESCO_START_VOLTAGE
        self._innesco_history = []

        # create popup with exit button
        popup = QtWidgets.QDialog(self)
        popup.setWindowTitle("Innesco Tiristore")
        layout = QtWidgets.QVBoxLayout()
        label = QtWidgets.QLabel(
            "Test Innesco: Attendere il completamento del test"
        )
        label.setWordWrap(True)
        layout.addWidget(label)
        exit_btn = QtWidgets.QPushButton("Esci dal test")
        exit_btn.clicked.connect(self._exit_innesco_test)
        layout.addWidget(exit_btn)
        popup.setLayout(layout)
        self._innesco_popup = popup
        self._innesco_label = label  # keep reference for updates
        popup.adjustSize()
        popup.show()

        # timer for increment and measurement
        self._innesco_timer = QtCore.QTimer(self)
        self._innesco_timer.timeout.connect(self._innesco_step)
        self._innesco_timer.start(INNESCO_TIMER_INTERVAL_MS)

    def _innesco_step(self):
        # increment until measurement drops or max reached
        if self._innesco_voltage >= TEST_MAX_VOLTAGE:
            self._innesco_timer.stop()
            return
        # increase voltage
        self._innesco_voltage += 1
        self.ctrl.set_voltage(self._innesco_voltage)
        # measure and record
        try:
            measured = self.ctrl.measure_voltage()
        except Exception:
            measured = None
        if measured is not None:
            self._innesco_history.append(measured)
            # check drop compared to previous
            if len(self._innesco_history) >= 2 and measured < self._innesco_history[-2]:
                    # stop the increments
                    self._innesco_timer.stop()
                    # find highest recorded value during test (including drop)
                    highest = max(self._innesco_history)
                    # schedule raw diode drop measurement after 1 second
                    QtCore.QTimer.singleShot(INNESCO_DIODE_DELAY_MS, lambda: self._calculate_diode_drop(highest))
    def _calculate_diode_drop(self, highest: float):
        # measure voltage again and update label with highest and raw diode drop
        try:
            raw = self.ctrl.measure_voltage()
        except Exception:
            raw = None
        if hasattr(self, '_innesco_label'):
            text = f"Valore massimo raggiunto: {highest} V\n"
            if raw is not None:
                adjusted = raw - INNESCO_DIODE_OFFSET_V
                text += f"Caduta diodo: {adjusted:.2f} V\n"
            text += "registrare il valore di tensione più alto raggiunto e la caduta di tensione"
            # append initial countdown text
            self._shutdown_counter = 3
            text += f"\nSpegnimento in {self._shutdown_counter} secondi..."
            self._innesco_label.setText(text)
            # start recurring timer to update countdown
            self._shutdown_timer = QtCore.QTimer(self)
            self._shutdown_timer.timeout.connect(self._shutdown_countdown_step)
            self._shutdown_timer.start(1000)
        else:
            # if there is no label available still schedule shutdown to be safe
            self._shutdown_counter = 0
            if self.ctrl:
                try:
                    self.ctrl.output_off()
                except Exception:
                    pass

    def _shutdown_countdown_step(self):
        # decrement the countdown and update the popup text; shut off output
        # when it reaches zero.
        if hasattr(self, '_shutdown_counter'):
            # reduce first so we never announce zero twice
            self._shutdown_counter -= 1
            if hasattr(self, '_innesco_label'):
                # append the new countdown line to whatever is already shown
                self._innesco_label.setText(
                    self._innesco_label.text().rsplit('\n', 1)[0]
                    + f"\nSpegnimento in {self._shutdown_counter} secondi..."
                )
        if self._shutdown_counter <= 0:
            # stop timer and actually switch output off
            if hasattr(self, '_shutdown_timer'):
                self._shutdown_timer.stop()
            if self.ctrl:
                try:
                    self.ctrl.output_off()
                except Exception:
                    pass

    def _exit_innesco_test(self):
        if hasattr(self, "_innesco_timer"):
            self._innesco_timer.stop()
        if self.ctrl:
            self.ctrl.output_off()
            try:
                self.ctrl.local_mode()
            except Exception:
                pass
        if hasattr(self, "_innesco_popup"):
            self._innesco_popup.close()
            del self._innesco_popup


    def _on_measure_complete(self, voltage: float, elapsed: float):
        self.result_label.setText(
            f"V: {voltage} V (took {elapsed:.3f}s)"
        )
        self.measure_btn.setEnabled(True)
        # cleanup worker reference
        self._measure_worker = None
