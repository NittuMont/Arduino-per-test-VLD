@echo off
cd /d "%~dp0"

echo Installazione dipendenze...
pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERRORE: pip non trovato. Assicurarsi che Python sia installato
    echo e che "Add Python to PATH" sia stato selezionato durante l'installazione.
    pause
    exit /b 1
)

echo.
echo Avvio programma...
python -m itech_interface.main
